# New buy box on the main product page and -2

Three files for the live theme (Clone Of Live | Buy Box Redesign [31-08]). Copy them in this order:

1. `sections/muto-crea-buy.liquid`: adds one optional setting, **Rating link**. Product pages that don't use it don't change.
2. `templates/product.muto-nad-performance.json`: the **main** product page (/products/muto-nad-cellular-complex).
3. `templates/product.muto-nad-45.json`: the **-2** page.

Both templates were built from the live copies taken on 17 October, so your edits are kept.

## What the buy box looks like (both pages)

- **Title block:**
  - Rating, linked to the reviews.
  - MUTO, then "NAD+ Cellular Complex" on one line.
  - "Serving: 30-day supply (60 capsules), 2 a day".
  - Descriptor: "Your daily NAD+ formula, made for adults over 35."
  - One paragraph on what it is and what's in it.
  - An "Ingredients + nutritional information" link that opens the ingredients fold.
- **Benefits:** six items in two columns. The trust pills are removed.
- **"Choose your plan"**, then two expanding boxes. Quarterly is first and open on load. Clicking a box opens it.
  - Bar on top: "New customer offer, free welcome kit worth £77".
  - **Quarterly plan:** Save 28% + free gifts, £150 with £210 struck through, "Billed £150 every 3 months · £1.67 a day". Ticks: kit worth £77, gifts in boxes 2 and 3 then creatine every box, cancel or pause anytime, 90-day money-back guarantee. Welcome kit tiles: Creatine, Socks, Jar, Bottle, Guide, Garmin entry. Future gifts: box 2 Socks, Creatine and £10 credit; box 3 Creatine and expert chat; from box 4 Creatine every box.
  - **Monthly plan:** Save 14% + free gifts, £60 with £70 struck through, "Billed £60 every 4 weeks · £2 a day". Kit worth £62: Creatine, Socks, Jar, Guide, Garmin entry. Future gifts: box 2 Bottle; box 3 Socks; box 4 Creatine and £10 credit; box 6 Creatine and expert chat.
- **One-time purchase** is its own row. The button reads "Subscribe · ~~£210~~ £150" or "Subscribe · ~~£70~~ £60", following the selected plan.
- **Desktop gallery:** the thumbnails sit in their own column left of the main image.

## How it's built

- **Template-only.** Copy in the plan and gift blocks, styling and a small script in a Custom Liquid block (`easy_read`) at the bottom of each template. The main page didn't have that block, so it's added. Nothing else on the page changes.
- **Plans are shown, not hidden.** The quarterly plan is no longer hidden (`hidden_plans` is empty). Prices come from Skio: 1-month £60, 3-month £150.
- **Gift tagging.** Gifts are tagged by plan, with 1 = monthly and 2 = quarterly in Skio's order. Empty means both plans. The Bottle is quarterly-only on the first box.
- **Block limit.** The section allows 50 blocks. The main page uses 47, so remove a block before adding a new one there.
- **-2 only.** -2 also keeps its below-the-buy-box text sizes back at standard.
