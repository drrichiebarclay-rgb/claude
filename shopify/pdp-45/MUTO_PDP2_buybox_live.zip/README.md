# -2 product page: new buy box (Artah-style) + rating link

Two files for the live theme (Clone Of Live | Buy Box Redesign [31-08]). Copy them in this order:

1. `sections/muto-crea-buy.liquid`: adds one optional setting, **Rating link**. Other product pages using this section don't change unless the setting is filled in.
2. `templates/product.muto-nad-45.json`: the -2 page. Built from the live copy taken on 17 October, so your edits are kept.

## What changes on -2

- **Title block:**
  - "NAD+ Cellular Complex" on one line.
  - A descriptor line: "Your daily NAD+ formula, made for adults over 40."
  - A "Serving: 30-day supply (60 capsules), 2 a day" line.
  - One short paragraph on what it is and what's in it.
  - An "Ingredients + nutritional information" link that opens the What's inside fold.
- **Benefits:** six items in two columns with rules, replacing the four bullet points. The three trust pills are hidden.
- **"Choose your plan"** heading with a rule either side.
- **Plan card:**
  - "Monthly subscription", a "Save 14%" badge, £60/mo with £70 struck through.
  - "£2 a day. £60 every 4 weeks."
  - Four plan bullets in two columns.
  - Then "Free in your first box (worth £62)" and the gifts in boxes 2 to 6.
- **One-time purchase** is now its own row above the button. The button reads "Subscribe · £60".
- **Smaller text throughout.** The earlier larger sizes are replaced.
- **Rating link:** the star line links to the reviews (`#ReviewsWidget`).

All styling lives in the page's own Custom Liquid block (`easy_read`) at the bottom of the template, so no other page is affected. To undo, restore the previous version of the template from the theme's version history.
