# -2 product page: new buy box (Artah-style) + rating link

Two files for the live theme (Clone Of Live | Buy Box Redesign [31-08]). Copy them in this order:

1. `sections/muto-crea-buy.liquid`: adds one optional setting, **Rating link**. Other product pages using this section don't change unless the setting is filled in.
2. `templates/product.muto-nad-45.json`: the -2 page. Built from the live copy taken on 17 October, so your edits are kept.

## What changes on -2

- **Title block:**
  - "NAD+ Cellular Complex" on one line.
  - A descriptor line: "Your daily NAD+ formula, made for adults over 35."
  - A "Serving: 30-day supply (60 capsules), 2 a day" line.
  - One short paragraph on what it is and what's in it.
  - An "Ingredients + nutritional information" link that opens the What's inside fold.
- **Benefits:** six items in two columns with rules, replacing the four bullet points. The three trust pills are hidden.
- **"Choose your plan"** heading with a rule either side.
- **Two plans, each in its own box, quarterly first and pre-selected.** Skio lists monthly first, so the page CSS reorders the boxes and a small script selects quarterly on load. The bullets and the button price follow the selection.
  - **Monthly plan:** "Save 14% + free gifts", £60 with £70 struck through, "£2 a day. £60 every 4 weeks."
  - **Quarterly plan:** "Save 28% + free gifts", £150 with £210 struck through, "£50 a month, about £1.67 a day. £150 every 3 months." The template no longer hides it (`hidden_plans` is now empty).
  - The chosen plan's four bullets show in a grey box underneath, then "Free in your first box (worth £62)" and the gifts in boxes 2 to 6, for both plans.
- **Each plan is one complete box, both always shown (no toggling).** Each plan's gifts and terms sit inside its own box, under its price, written in that plan's Detail field:
  - **Quarterly (shown first), first box worth £77:** Creatine £30, Socks £12, Jar to keep £10, Performance Bottle £15, 12-week guide £10, Garmin draw entry. Box 2: Socks, Creatine, £10 store credit. Box 3: Creatine and a chat with an expert. From box 4: Creatine in every box.
  - **Monthly, first box worth £62:** Creatine £30, Socks £12, Jar to keep £10, 12-week guide £10, Garmin draw entry. Box 2: Bottle. Box 3: Socks. Box 4: Creatine and £10 credit. Box 6: Creatine and a chat with an expert.
  - Clicking anywhere in a plan's box selects that plan, and the selected box gets the thicker outline.
  - The section's shared gift area (with photo tiles) is hidden on this page. The gift blocks are still in the template, each tagged to its plan, if you want the photos back later.
  - The bar on top reads "Free welcome kit with your first box".
- **Quarterly price comes from Skio.** The cards show Skio's real price. The 3-MONTH SUBSCRIPTION is £135 in Skio today, so change it to **£150** in Skio before this goes live, or the card will show £135 next to a "Save 28%" badge.
- **One-time purchase** is now its own row above the button. The button shows the selected plan with its old price struck through: "Subscribe · ~~£210~~ £150" (quarterly) or "Subscribe · ~~£70~~ £60" (monthly). The page script adds the struck price and updates it when the plan changes.
- **Desktop gallery:** the thumbnails sit in their own column to the left of the main image instead of over it (990px and wider). On mobile they stay in a row under the image.
- **Smaller text throughout.** The earlier larger sizes are replaced.
- **Rating link:** the star line links to the reviews (`#ReviewsWidget`).

All styling lives in the page's own Custom Liquid block (`easy_read`) at the bottom of the template, so no other page is affected. To undo, restore the previous version of the template from the theme's version history.
